export default function Home() {
  return (
    <main>
      <section style={{ padding: '4rem 2rem', textAlign: 'center', background: '#f0fdf4' }}>
        <h1 style={{ fontSize: '2.5rem', fontWeight: 'bold' }}>Новое поколение</h1>
        <p style={{ fontSize: '1.2rem', marginTop: '1rem' }}>
          Федеральная платформа для развития среды, здоровья и возможностей для дошкольников
        </p>
        <button style={{ marginTop: '2rem', padding: '1rem 2rem', fontSize: '1rem' }}>Присоединиться</button>
      </section>
    </main>
  );
}